﻿```ngMeta
name: Introduction To Python
type: html
short_description: In this topic we will study about the Introduction of Python.
logo: https://bit.ly/1h4FwSY
```
