﻿```ngMeta
name: What is Programming?
```

By giving** instructions** to the computer,we can make the computers solve complex problems.

A set of **instructions** given to the computer is called a **program** .
The Process of giving instructions to the computer is called **programming**.

Doesn't it sound simple that we give instructions(program) to the computer and the computer follows these instructions to solve a complex problem.Giving instructions to the computer is called programming. :)

But there is a small problem.

Computers cannot understand our language like (Hindi , Tamil ,  Kannada) .Computers can only understand the machine language which is made of 0 and 1.So ,it becomes difficult for us to communicate with computer in machine language.

Then how can we give instructions to the computer ?

Therefore , to solve this problem we made some languages like(Java, Python, JavaScript) so that we can easily give instructions to the computer. Computers can easily convert these languages into machine language with the help of “another program called compiler.”

To give instructions to the computer we need to learn any of these given languages. In this course, we are going to learn python language.

We will use python language to give instructions to the computer.

**Assignment**
- Have you ever given instructions to anybody or taken instructions from anybody. Can we call that a **program**?
-   Search for Python language and its applications ?How many people in the world use Java?
