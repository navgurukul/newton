﻿```ngMeta
name: Introduction
```

**Introduction of Python in English :-**

@[youtube](UlpurGz1-TU) 



**Introduction of Python in Hindi :-**

@[youtube](iWNpVTYSt74) 
