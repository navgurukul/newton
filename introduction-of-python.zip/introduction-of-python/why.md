﻿```ngMeta
name: Why do I need to learn Python  ??
```


[Introduction of Python in English
](https://www.youtube.com/watch?v=UlpurGz1-TU&t=9s)


[Introduction of Python in Hindi
](https://www.youtube.com/watch?v=iWNpVTYSt74)



### Difference Between Python2 and Python3

**Python2**

```python
Print "Hello World"
```

1. This is old version of python .
2. Python2 has one print statement.
3. In Python2 while printing we write like this ,


4. In Python2 we use raw_input ka use for user input.

```python 
age= int(raw_input("enter your age"))
```

5. Python2 has 31 keywords .



**Python3**


1. This is the new version of python .
2. Python3 has one print() .
3. In Python3 me while  printing  we use parentheses () .
```python
print("Hello World")
 ```
4. In Python3 we use input for user's input .
```python
 age=int(input("please enter your age"))
  ```
5. Python3 has 35 keywords .

