﻿```ngMeta
name: What Do Computers Do?
```

In our human history, there have been some great inventions which have brought progress in the lives of humans and have also provided direction to it.Ex:**WHEEL**

Humans were not able to lift or carry heavy loads to longer distances. This was due to human’s physical limitation.
By the invention of WHEEL, humans were able to carry very heavy loads as well as to travel to longer distances also.
The world became smaller to us.Hence,the invention of WHEEL solved lots of problems. Now, we can even meet our relatives staying far off and transportation of goods also became easier.

Another great invention that brought a drastic change in human history-**COMPUTER**.

Just as WHEELS removed our physical limitations, similarly COMPUTERS helped in expanding our brain capacity or mental limitations.

Human brain can solve many complex tasks/problems. But if our brain continuously solves these complex problems ,our brain will start getting tired or bored. Our brain will start making mistakes and it becomes difficult for us to solve the problem.

Just as wheels removed our physical limitation, invention of computers, helped in removing our mental limitations. By giving instructions to the Computer, we can make them perform complex tasks, continuously without making any mistakes and without getting tired.

Computers don’t have their own brain so they can’t think, we have to give instructions to them to make them solve any complex problem.


**Read and search the following questions.**
--   What did you learn about computers?
--   What are the applications of computers ?What kinds of problems do these applications solve? Think about what kind of instructions were given to computers for these applications?
