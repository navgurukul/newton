```ngMeta
comments_key1
```

comments_key2


comments_key3
```python
print ("This will be printed.")
print ("This line will also be printed")
# This is a comment.
# You can write it for your ease.
# Any line that starts with "#" (hash) is called a  comment.
# We write these lines as programmers, for our own ease. Computer ignores them.
print ("Computer will not be able to read above comments,but will print this line.")
```
comments_key4
comments_key5
