definitions-part-1_key1
definitions-part-1_key2
definitions-part-1_key3


definitions-part-1_key4


```python
a=5
b=9
print(a+b)
```
definitions-part-1_key5


definitions-part-1_key6


definitions-part-1_key7


definitions-part-1_key8


definitions-part-1_key9


definitions-part-1_key10


[definitions-part-1_key11](https://youtu.be/SDxPjsRksw0)


definitions-part-1_key12
definitions-part-1_key13


definitions-part-1_key14


definitions-part-1_key15


definitions-part-1_key16
```python
a=5
b=7
print(a+b)
```
definitions-part-1_key17


definitions-part-1_key18


definitions-part-1_key19


[definitions-part-1_key20](https://youtu.be/ZMMVf4Qv)

 
definitions-part-1_key21
definitions-part-1_key22


definitions-part-1_key23


definitions-part-1_key24



definitions-part-1_key25
definitions-part-1_key26



[definitions-part-1_key27](https://youtu.be/bqyVOEgDSj8)


definitions-part-1_key28
definitions-part-1_key29


definitions-part-1_key30


definitions-part-1_key31


definitions-part-1_key32


```python
num=5
print(num
```
definitions-part-1_key33


definitions-part-1_key34


```python
num=5
print "a"
```
definitions-part-1_key35


definitions-part-1_key36


definitions-part-1_key37



definitions-part-1_key38
definitions-part-1_key39



definitions-part-1_key40


definitions-part-1_key41



definitions-part-1_key42


definitions-part-1_key43


definitions-part-1_key44


[definitions-part-1_key45](https://youtu.be/MvayENwOCNM)
