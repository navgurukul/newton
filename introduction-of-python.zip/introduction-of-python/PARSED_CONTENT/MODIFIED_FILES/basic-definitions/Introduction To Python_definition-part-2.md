definition-part-2_key1
definition-part-2_key2
definition-part-2_key3



definition-part-2_key4
definition-part-2_key5


definition-part-2_key6


definition-part-2_key7


```python
a = megha
print (a)
```
definition-part-2_key8


definition-part-2_key9


definition-part-2_key10
definition-part-2_key11


definition-part-2_key12

 
[definition-part-2_key13](https://www.`youtube`.com/watch?v=e4ax90XmUBc&t=156s)


definition-part-2_key14
definition-part-2_key15


definition-part-2_key16


```python
var = 5
print(Var)
```
definition-part-2_key17


definition-part-2_key18


definition-part-2_key19


[definition-part-2_key20](https://youtu.be/mNxDbLBBzno)



definition-part-2_key21
definition-part-2_key22


```python
num=5
print(num
```
definition-part-2_key23


definition-part-2_key24


```python
num=5
print "a"
```
definition-part-2_key25


definition-part-2_key26



definition-part-2_key27


definition-part-2_key28
definition-part-2_key29


definition-part-2_key30


```python
num=5
print(num)
```
definition-part-2_key31


definition-part-2_key32


```python
num=2
Print (num)
```
definition-part-2_key33


definition-part-2_key34


definition-part-2_key35


definition-part-2_key36
definition-part-2_key37
```python
name="python"
print(name)
```
definition-part-2_key38


definition-part-2_key39


definition-part-2_key40



![Types of brackets](https://www.grammar-monster.com/glossary/pics/types_of_brackets.png)