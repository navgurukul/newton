```ngMeta
why_key1
```








why_key2
why_key3


```python
Print "Hello World"
```
1. why_key4
2. why_key5
3. why_key6
4. why_key7
```python
age= int(raw_input("enter your age"))
```
5. why_key8
why_key9



1. why_key10
2. why_key11
3. why_key12
```python
print("Hello World")
```
4. why_key13
```python
age=int(input("please enter your age"))
```
5. why_key14
