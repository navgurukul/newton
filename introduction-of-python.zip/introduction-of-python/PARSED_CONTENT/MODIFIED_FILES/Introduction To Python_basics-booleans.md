```ngMeta
basics-booleans_key1
```

basics-booleans_key2
basics-booleans_key3


basics-booleans_key4


1. basics-booleans_key5
2. basics-booleans_key6
basics-booleans_key7


basics-booleans_key8


basics-booleans_key9


basics-booleans_key10
basics-booleans_key11



|basics-booleans_key12|basics-booleans_key13|basics-booleans_key14|
|-----------|-----------|-----------|
|basics-booleans_key15|basics-booleans_key16|basics-booleans_key17|
|basics-booleans_key18|basics-booleans_key19|basics-booleans_key20|
|basics-booleans_key21|basics-booleans_key22|basics-booleans_key23|
|basics-booleans_key24|basics-booleans_key25|basics-booleans_key26|
|basics-booleans_key27|basics-booleans_key28|basics-booleans_key29|
|basics-booleans_key30|basics-booleans_key31|basics-booleans_key32|

basics-booleans_key33


```python
4 < 5 # True
```
```python
56 == 45 # False
```
basics-booleans_key34
