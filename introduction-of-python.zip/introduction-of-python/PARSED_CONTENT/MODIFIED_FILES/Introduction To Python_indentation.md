```ngMeta
indentation_key1
```

indentation_key2
indentation_key3
```python
a = 10
if a * 2 == 20:
print ("Variable a when multiplied by 2 gives 20.")
else:
print ("Variable a when mutiplied by 2 does not give 20.")
```
indentation_key4


1. indentation_key5
2. indentation_key6
3. indentation_key7
indentation_key8


```python
a = 10
if a * 2 == 20:
    print ( )
else:
    print ("Variable a when mutiplied by 2 does not give 20.")
```
indentation_key9


1. indentation_key10
2. indentation_key11
3. indentation_key12
4. indentation_key13
indentation_key14


```python
  File "<ipython-input-5-9eaf99c4383b>", line 3
    print ("a variable ko 2 se multiply kar ke 20 aata hai")
        ^
IndentationError: expected an indented block
```
indentation_key15
indentation_key16
```python
counter = 1
while counter < 10:
    print ("The counter is" + str(counter))
    counter = counter + 1
    print ('--------')
```
indentation_key17


1. indentation_key18
2. indentation_key19
```python
counter = 1
while counter < 10:
 print ("The counter is" + str(counter))
 counter = counter + 1
print ('--------')
```
indentation_key20


indentation_key21


indentation_key22
indentation_key23


```python
counter = 1
while counter < 10:
    if counter % 2 == 0:
        print ("Counter is an even number.")
    print ("The counter is" + str(counter))
    counter = counter + 1
print ('--------')
```
indentation_key24


1. indentation_key25
2. indentation_key26
indentation_key27
