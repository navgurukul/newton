ipython_key1
ipython_key2



ipython_key3


ipython_key4
ipython_key5
ipython_key6



ipython_key7
ipython_key8


ipython_key9


```python
>>> cd Downloads
  File "<stdin>", line 1
    cd Downloads
               ^
SyntaxError: invalid syntax
>>> 
```
ipython_key10


ipython_key11


ipython_key12


ipython_key13


ipython_key14
```python
>>> if True:
... 
```
ipython_key15


```python
In [1]: if True:
   ...:     |
```
ipython_key16


ipython_key17



ipython_key18
- ipython_key19
- ipython_key20
- ipython_key21
- ipython_key22
ipython_key23
ipython_key24


ipython_key25
```python
print ("It will print this.")
print ("Cool Stuff "*10)
```
ipython_key26
```python
time = input("Is it morning or evening? (morning/evening) ")
if time == "morning":
    print ("Let's go for a run!")
elif time == "evening":
    print ("Let's go out for a coffee.")
else:
    print ("I did not understand what input you put?")
```
