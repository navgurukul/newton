```ngMeta
how-to-begin_key1
```

how-to-begin_key2
how-to-begin_key3
@[`youtube`](ccPrUbz1oto) 

how-to-begin_key4


how-to-begin_key5
```sh
$ python
```
```python

print("This line will be printed in python.")
print("This,another line will also be printed in python")
print(2 + 5)
i = 0
print(i)
while i < 100:
    print("I will be printed again and again.:)")

```
how-to-begin_key6


how-to-begin_key7


how-to-begin_key8




how-to-begin_key9
```python
print ("This line will be printed in python.")
```
how-to-begin_key10
```python
print ("This,another line will also be printed in python")
```
how-to-begin_key11
```python
print (2 + 5)
```
how-to-begin_key12
```python
print ("This line will be printed in python.")
print ("This,another line will also be printed in python")
print (2 + 5)
```
how-to-begin_key13
```python
i = 0
print (i)
```
how-to-begin_key14
```python
i = 0
while i < 100:
    print ("I will be printed again and again.:)"
```
how-to-begin_key15
```python
i = 0
while i < 100:
    print ("I will be printed again and again:)")
    i = i+1
```
how-to-begin_key16
```python
print ("This line will be printed in python.")
print ("This,another line will also be printed in python")
print (2 + 5)
i = 0
print (i)
while i < 100:
    print ("I will be printed again and again.:)")
```
how-to-begin_key17


how-to-begin_key18



how-to-begin_key19
- how-to-begin_key20
- how-to-begin_key21
- how-to-begin_key22
-During how-to-begin_key23
