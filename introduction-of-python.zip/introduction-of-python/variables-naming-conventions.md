﻿```ngMeta
name: How to name variables?
```

Variables names should be very descriptive so that whosoever is reading the codey should be able to understand. the code -
