```ngMeta
the-in-and-not-in-operators_key1
```
# the-in-and-not-in-operators_key2
the-in-and-not-in-operators_key3
```python
>>> 'howdy' in ['hello', 'hi', 'howdy', 'heyas']
True
>>> spam = ['hello', 'hi', 'howdy', 'heyas']
>>> 'cat' in spam
False
>>> 'howdy' not in spam
False
>>> 'cat' not in spam
True
```
the-in-and-not-in-operators_key4
```python
myPets = ['Zophie', 'Pooka', 'Fat-tail']
print('Enter a pet name:')
name = input()
if name not in myPets:
    print('I do not have a pet named ' + name)
else:
    print(name + ' is my pet.')
```
the-in-and-not-in-operators_key5

the-in-and-not-in-operators_key6