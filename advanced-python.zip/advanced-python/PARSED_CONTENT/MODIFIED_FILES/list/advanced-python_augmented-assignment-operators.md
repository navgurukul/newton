```ngMeta
augmented-assignment-operators_key1
```
# augmented-assignment-operators_key2
augmented-assignment-operators_key3
```python
>>> spam = 42
>>> spam = spam + 1
>>> spam
43
```
augmented-assignment-operators_key4
```python
>>> spam = 42
>>> spam += 1
>>> spam
43
```
augmented-assignment-operators_key5```python
spam += 1        spam = spam + 1

spam -= 1        spam = spam - 1

spam *= 1        spam = spam * 1

spam /= 1        spam = spam / 1

spam %= 1        spam = spam % 1
```
augmented-assignment-operators_key6```python
>>> spam = 'Hello'
>>> spam += ' world!'
>>> spam
'Hello world!'

>>> bacon = ['Zophie']
>>> bacon *= 3
>>> bacon
['Zophie', 'Zophie', 'Zophie']
```
