```ngMeta
the-copy-module’s-copy()-and-deepcopy()-functions_key1
```
# the-copy-module’s-copy()-and-deepcopy()-functions_key2
the-copy-module’s-copy()-and-deepcopy()-functions_key3
```python
>>> import copy
>>> spam = ['A', 'B', 'C', 'D']
>>> cheese = copy.copy(spam)
>>> cheese[1] = 42
>>> spam
['A', 'B', 'C', 'D']
>>> cheese
['A', 42, 'C', 'D']
```
the-copy-module’s-copy()-and-deepcopy()-functions_key4
the-copy-module’s-copy()-and-deepcopy()-functions_key5
the-copy-module’s-copy()-and-deepcopy()-functions_key6# the-copy-module’s-copy()-and-deepcopy()-functions_key7
the-copy-module’s-copy()-and-deepcopy()-functions_key8
the-copy-module’s-copy()-and-deepcopy()-functions_key9
the-copy-module’s-copy()-and-deepcopy()-functions_key10