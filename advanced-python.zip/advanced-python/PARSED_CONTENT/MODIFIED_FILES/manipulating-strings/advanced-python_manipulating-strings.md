```ngMeta
manipulating-strings_key1
```
# manipulating-strings_key2
manipulating-strings_key3
manipulating-strings_key4
# manipulating-strings_key5
manipulating-strings_key6
# manipulating-strings_key7
manipulating-strings_key8
# manipulating-strings_key9
manipulating-strings_key10
```python
>>> spam = "That is Alice's cat."
```
manipulating-strings_key11
# manipulating-strings_key12
manipulating-strings_key13\)manipulating-strings_key14\'manipulating-strings_key15
```python
>>> spam = 'Say hi to Bob\'s mother.'
```
manipulating-strings_key16\'manipulating-strings_key17\'manipulating-strings_key18\"manipulating-strings_key19
manipulating-strings_key20
manipulating-strings_key21
manipulating-strings_key22
manipulating-strings_key23
\'
manipulating-strings_key24
\"
manipulating-strings_key25
manipulating-strings_key26
manipulating-strings_key27
manipulating-strings_key28
manipulating-strings_key29
\\
manipulating-strings_key30
manipulating-strings_key31
```python
>>> print("Hello there!\nHow are you?\nI\'m doing fine.")
```
manipulating-strings_key32
```python
>>> print(r'That is Carol\'s cat.')
```
manipulating-strings_key33\'manipulating-strings_key34