```ngMeta
indexing-and-slicing-strings_key1
```
# indexing-and-slicing-strings_key2
indexing-and-slicing-strings_key3

indexing-and-slicing-strings_key4
indexing-and-slicing-strings_key5
```python
>>> spam = 'Hello world!'
>>> spam[0]
'H'
>>> spam[4]
'o'
>>> spam[-1]
'!'
>>> spam[0:5]
'Hello'
>>> spam[:5]
'Hello'
>>> spam[6:]
'world!'
```
indexing-and-slicing-strings_key6
indexing-and-slicing-strings_key7
```python
>>> spam = 'Hello world!'
>>> fizz = spam[0:5]
>>> fizz
'Hello'
```
indexing-and-slicing-strings_key8
indexing-and-slicing-strings_key9
```python
>>> 'Hello' in 'Hello World'
True
>>> 'Hello' in 'Hello'
True
>>> 'HELLO' in 'Hello World'
False
>>> '' in 'spam'
True
>>> 'cats' not in 'cats and dogs'
False
```
indexing-and-slicing-strings_key10
