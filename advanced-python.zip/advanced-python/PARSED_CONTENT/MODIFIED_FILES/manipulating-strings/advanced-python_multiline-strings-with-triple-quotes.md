```ngMeta
multiline-strings-with-triple-quotes_key1
```
# multiline-strings-with-triple-quotes_key2
multiline-strings-with-triple-quotes_key3
multiline-strings-with-triple-quotes_key4
```python
print('''Dear Alice,

Eve's cat has been arrested for catnapping, cat burglary, and extortion.

Sincerely,
Bob''')
```
multiline-strings-with-triple-quotes_key5

multiline-strings-with-triple-quotes_key6
multiline-strings-with-triple-quotes_key7
multiline-strings-with-triple-quotes_key8

multiline-strings-with-triple-quotes_key9\'multiline-strings-with-triple-quotes_key10# multiline-strings-with-triple-quotes_key11
multiline-strings-with-triple-quotes_key12

multiline-strings-with-triple-quotes_key13[multiline-strings-with-triple-quotes_key14](mailto:&#x61;&#108;&#64;&#105;&#x6e;&#118;&#x65;&#110;&#x74;&#119;&#x69;&#116;&#104;&#x70;&#x79;&#116;&#x68;&#111;&#x6e;&#x2e;&#x63;&#111;&#x6d;)

multiline-strings-with-triple-quotes_key15```python
def spam():
    """This is a multiline comment to help
    explain what the spam() function does."""
    print('Hello!')
```
