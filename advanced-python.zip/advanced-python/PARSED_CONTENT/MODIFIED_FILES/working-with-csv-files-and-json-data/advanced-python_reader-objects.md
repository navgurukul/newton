```ngMeta
reader-objects_key1
```
# reader-objects_key2
reader-objects_key3
```python
❶ >>> import csv
❷ >>> exampleFile = open('example.csv')
❸ >>> exampleReader = csv.reader(exampleFile)
❹ >>> exampleData = list(exampleReader)
❹ >>> exampleData
```
reader-objects_key4
reader-objects_key5
reader-objects_key6
reader-objects_key7
```python
>>> exampleData[0][0]
```
reader-objects_key8```python
>>> exampleData[0][1]
```
reader-objects_key9```python
>>> exampleData[0][2]
```
reader-objects_key10```python
>>> exampleData[1][1]
```
reader-objects_key11```python
>>> exampleData[6][1]
```
reader-objects_key12