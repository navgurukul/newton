```ngMeta
keeping-time-scheduling-tasks-and-launching-programs_key1
```
# keeping-time-scheduling-tasks-and-launching-programs_key2
keeping-time-scheduling-tasks-and-launching-programs_key3
keeping-time-scheduling-tasks-and-launching-programs_key4# keeping-time-scheduling-tasks-and-launching-programs_key5
keeping-time-scheduling-tasks-and-launching-programs_key6
# keeping-time-scheduling-tasks-and-launching-programs_key7
keeping-time-scheduling-tasks-and-launching-programs_key8
```python
>>> import time
>>> time.time()
```
keeping-time-scheduling-tasks-and-launching-programs_key9
# keeping-time-scheduling-tasks-and-launching-programs_key10
keeping-time-scheduling-tasks-and-launching-programs_key11
keeping-time-scheduling-tasks-and-launching-programs_key12
```python
   import time
❶ def calcProd():
       # Calculate the product of the first 100,000 numbers.
       product = 1
       for i in range(1, 100000):
           product = product * i
       return product

❷ startTime = time.time()
   prod = calcProd()
❸ endTime = time.time()
❹ print('The result is %s digits long.' % (len(str(prod))))
❺ print('Took %s seconds to calculate.' % (endTime - startTime))
```
keeping-time-scheduling-tasks-and-launching-programs_key13
keeping-time-scheduling-tasks-and-launching-programs_key14

keeping-time-scheduling-tasks-and-launching-programs_key15
# keeping-time-scheduling-tasks-and-launching-programs_key16
keeping-time-scheduling-tasks-and-launching-programs_key17keeping-time-scheduling-tasks-and-launching-programs_key18
