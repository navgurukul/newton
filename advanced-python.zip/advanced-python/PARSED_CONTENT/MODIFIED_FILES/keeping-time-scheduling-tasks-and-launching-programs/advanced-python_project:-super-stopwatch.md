```ngMeta
project:-super-stopwatch_key1
```
# project:-super-stopwatch_key2
project:-super-stopwatch_key3
project:-super-stopwatch_key4
project:-super-stopwatch_key5
project:-super-stopwatch_key6
project:-super-stopwatch_key7
project:-super-stopwatch_key8
project:-super-stopwatch_key9
project:-super-stopwatch_key10
project:-super-stopwatch_key11
project:-super-stopwatch_key12
# project:-super-stopwatch_key13
project:-super-stopwatch_key14
project:-super-stopwatch_key15

# project:-super-stopwatch_key16
# project:-super-stopwatch_key17
project:-super-stopwatch_key18
# project:-super-stopwatch_key19
project:-super-stopwatch_key20
# project:-super-stopwatch_key21
project:-super-stopwatch_key22
# project:-super-stopwatch_key23
project:-super-stopwatch_key24

project:-super-stopwatch_key25 project:-super-stopwatch_key26
project:-super-stopwatch_key27
project:-super-stopwatch_key28```python
   # Start tracking the lap times.
❶ try:
❷    while True:
           input()
❸         lapTime = round(time.time() - lastTime, 2)
❹         totalTime = round(time.time() - startTime, 2)
❺         print('Lap #%s: %s (%s)' % (lapNum, totalTime, lapTime), end='')
           lapNum += 1
           lastTime = time.time() # reset the last lap time
❻ except KeyboardInterrupt:
```
project:-super-stopwatch_key29
project:-super-stopwatch_key30
project:-super-stopwatch_key31
# project:-super-stopwatch_key32
project:-super-stopwatch_key33
project:-super-stopwatch_key34
project:-super-stopwatch_key35
project:-super-stopwatch_key36