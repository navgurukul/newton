```ngMeta
task-scheduler-launchd-and-cron_key1
```
# task-scheduler-launchd-and-cron_key2
task-scheduler-launchd-and-cron_key3task-scheduler-launchd-and-cron_key4task-scheduler-launchd-and-cron_key5
task-scheduler-launchd-and-cron_key6
# task-scheduler-launchd-and-cron_key7
task-scheduler-launchd-and-cron_key8
# task-scheduler-launchd-and-cron_key9
task-scheduler-launchd-and-cron_key10
```python
>>> subprocess.Popen(['C:\\python34\\python.exe', 'hello.py'])
```
task-scheduler-launchd-and-cron_key11
task-scheduler-launchd-and-cron_key12