```ngMeta
the-time-sleep()-function_key1
```
# the-time-sleep()-function_key2
the-time-sleep()-function_key3
```python
   >>> import time
   >>> for i in range(3):
❶         print('Tick')
❷         time.sleep(1)
❸         print('Tock')
❹         time.sleep(1)
```
the-time-sleep()-function_key4```python
❺ >>> time.sleep(5)
```
the-time-sleep()-function_key5
the-time-sleep()-function_key6
the-time-sleep()-function_key7
```python
>>> for i in range(30):
```
the-time-sleep()-function_key8
