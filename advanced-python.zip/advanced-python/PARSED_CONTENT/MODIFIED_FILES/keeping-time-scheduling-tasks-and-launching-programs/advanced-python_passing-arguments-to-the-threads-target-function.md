```ngMeta
passing-arguments-to-the-threads-target-function_key1
```
# passing-arguments-to-the-threads-target-function_key2
passing-arguments-to-the-threads-target-function_key3
```python
>>> print('Cats', 'Dogs', 'Frogs', sep=' & ')
```
passing-arguments-to-the-threads-target-function_key4
passing-arguments-to-the-threads-target-function_key5
```python
>>> import threading
>>> threadObj = threading.Thread(target=print, args=['Cats', 'Dogs', 'Frogs'],
kwargs={'sep': ' & '})
>>> threadObj.start()
```
passing-arguments-to-the-threads-target-function_key6
passing-arguments-to-the-threads-target-function_key7
passing-arguments-to-the-threads-target-function_key8

passing-arguments-to-the-threads-target-function_key9# passing-arguments-to-the-threads-target-function_key10
passing-arguments-to-the-threads-target-function_key11
passing-arguments-to-the-threads-target-function_key12
# passing-arguments-to-the-threads-target-function_key13
passing-arguments-to-the-threads-target-function_key14passing-arguments-to-the-threads-target-function_key15