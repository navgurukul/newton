```ngMeta
passing-command-line-arguments-to-open()_key1
```
# passing-command-line-arguments-to-open()_key2
passing-command-line-arguments-to-open()_key3
passing-command-line-arguments-to-open()_key4
```python
>>> subprocess.Popen(['C:\\Windows\\notepad.exe', 'C:\\hello.txt'])
```
passing-command-line-arguments-to-open()_key5
