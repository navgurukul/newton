```ngMeta
converting-datetime-objects-into-strings_key1
```
# converting-datetime-objects-into-strings_key2
converting-datetime-objects-into-strings_key3
converting-datetime-objects-into-strings_key4
converting-datetime-objects-into-strings_key5
|converting-datetime-objects-into-strings_key6|converting-datetime-objects-into-strings_key7|
|---|---|
|converting-datetime-objects-into-strings_key8|converting-datetime-objects-into-strings_key9|
converting-datetime-objects-into-strings_key10
converting-datetime-objects-into-strings_key11
converting-datetime-objects-into-strings_key12
converting-datetime-objects-into-strings_key13
converting-datetime-objects-into-strings_key14
converting-datetime-objects-into-strings_key15
converting-datetime-objects-into-strings_key16
converting-datetime-objects-into-strings_key17
converting-datetime-objects-into-strings_key18
converting-datetime-objects-into-strings_key19
converting-datetime-objects-into-strings_key20
converting-datetime-objects-into-strings_key21
converting-datetime-objects-into-strings_key22
converting-datetime-objects-into-strings_key23
converting-datetime-objects-into-strings_key24
converting-datetime-objects-into-strings_key25
```python
>>> oct21st = datetime.datetime(2015, 10, 21, 16, 29, 0)
>>> oct21st.strftime('%Y/%m/%d %H:%M:%S')
```
converting-datetime-objects-into-strings_key26```python
>>> oct21st.strftime('%I:%M %p')
```
converting-datetime-objects-into-strings_key27```python
>>> oct21st.strftime("%B of '%y")
```
converting-datetime-objects-into-strings_key28