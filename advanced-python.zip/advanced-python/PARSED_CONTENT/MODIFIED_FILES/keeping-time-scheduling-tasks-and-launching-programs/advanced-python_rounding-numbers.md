```ngMeta
rounding-numbers_key1
```
# rounding-numbers_key2
rounding-numbers_key3
```python
>>> import time
>>> now = time.time()
>>> now
```
rounding-numbers_key4```python
>>> round(now, 2)
```
rounding-numbers_key5```python
>>> round(now, 4)
```
rounding-numbers_key6```python
>>> round(now)
```
rounding-numbers_key7
