```ngMeta
project-simple-countdown-program_key1
```
# project-simple-countdown-program_key2
project-simple-countdown-program_key3
project-simple-countdown-program_key4
project-simple-countdown-program_key5
project-simple-countdown-program_key6
project-simple-countdown-program_key7
project-simple-countdown-program_key8
project-simple-countdown-program_key9
project-simple-countdown-program_key10
# project-simple-countdown-program_key11
project-simple-countdown-program_key12

project-simple-countdown-program_key13 project-simple-countdown-program_key14
```python
import time, subprocess

❶ timeLeft = 60
   while timeLeft > 0:
❷     print(timeLeft, end='')
❸     time.sleep(1)
❹     timeLeft = timeLeft - 1
```
 project-simple-countdown-program_key15
project-simple-countdown-program_key16
project-simple-countdown-program_key17
# project-simple-countdown-program_key18
project-simple-countdown-program_key19
project-simple-countdown-program_key20project-simple-countdown-program_key21
project-simple-countdown-program_key22

# project-simple-countdown-program_key23
# project-simple-countdown-program_key24
project-simple-countdown-program_key25
project-simple-countdown-program_key26```python
# At the end of the countdown, play a sound file.
subprocess.Popen(['start', 'alarm.wav'], shell=True)
```
project-simple-countdown-program_key27
project-simple-countdown-program_key28
# project-simple-countdown-program_key29
project-simple-countdown-program_key30
project-simple-countdown-program_key31
project-simple-countdown-program_key32
# project-simple-countdown-program_key33
project-simple-countdown-program_key34
project-simple-countdown-program_key35project-simple-countdown-program_key36project-simple-countdown-program_key37
project-simple-countdown-program_key38
project-simple-countdown-program_key39