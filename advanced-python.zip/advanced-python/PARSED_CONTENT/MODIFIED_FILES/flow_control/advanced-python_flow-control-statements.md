```ngMeta
flow-control-statements_key1
```
# flow-control-statements_key2
flow-control-statements_key3
# flow-control-statements_key4
flow-control-statements_key5
flow-control-statements_key6
flow-control-statements_key7
```python
if name == 'Alice':
    print('Hi, Alice.')
```
flow-control-statements_key8
flow-control-statements_key9
# flow-control-statements_key10
flow-control-statements_key11
flow-control-statements_key12```python
name = 'Bob'
if name == 'Alice':
    print('Hi, Alice.')
else:
    print('Hello, stranger.')
```
flow-control-statements_key13
flow-control-statements_key14
# flow-control-statements_key15
flow-control-statements_key16
flow-control-statements_key17
flow-control-statements_key18```python
name = 'Bob'
age = 5
if name == 'Alice':
    print('Hi, Alice.')
elif age < 12:
    print('You are not Alice, kiddo.')
```
flow-control-statements_key19
flow-control-statements_key20
flow-control-statements_key21
```python
name = 'Dracula'
age = 4000
if name == 'Alice':
    print('Hi, Alice.')
elif age < 12:
    print('You are not Alice, kiddo.')
elif age > 2000:
    print('Unlike you, Alice is not an undead, immortal vampire.')
elif age > 100:
    print('You are not Alice, grannie.')
```
flow-control-statements_key22
