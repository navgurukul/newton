```ngMeta
flow_state_key1
```
# flow_state_key2
flow_state_key3
# flow_state_key4
flow_state_key5
flow_state_key6
flow_state_key7
```python
if name == 'Alice':
    print('Hi, Alice.')
```
flow_state_key8
flow_state_key9
# flow_state_key10
flow_state_key11
flow_state_key12```python
name = 'Bob'
if name == 'Alice':
    print('Hi, Alice.')
else:
    print('Hello, stranger.')
```
flow_state_key13
flow_state_key14
# flow_state_key15
flow_state_key16
flow_state_key17
flow_state_key18```python
name = 'Bob'
age = 5
if name == 'Alice':
    print('Hi, Alice.')
elif age < 12:
    print('You are not Alice, kiddo.')
```
flow_state_key19
flow_state_key20
flow_state_key21
```python
name = 'Dracula'
age = 4000
if name == 'Alice':
    print('Hi, Alice.')
elif age < 12:
    print('You are not Alice, kiddo.')
elif age > 2000:
    print('Unlike you, Alice is not an undead, immortal vampire.')
elif age > 100:
    print('You are not Alice, grannie.')
```
flow_state_key22
