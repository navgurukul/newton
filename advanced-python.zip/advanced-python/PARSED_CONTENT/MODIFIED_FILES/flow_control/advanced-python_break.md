```ngMeta
break_key1
```
# break_key2
break_key3
break_key4
```python
while True:                         # (1)
    print('Please type your name.')
    name = input()                  # (2)
    if name == 'your name':         # (3)
        break                       # (4)
print('Thank you!')                 # (5)
```
break_key5
break_key6
break_key7

break_key8