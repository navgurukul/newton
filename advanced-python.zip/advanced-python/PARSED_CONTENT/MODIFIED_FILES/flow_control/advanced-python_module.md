```ngMeta
module_key1
```
# module_key2
module_key3
module_key4
module_key5
module_key6```python
import random
for i in range(5):
    print(random.randint(1, 10))
```
module_key7

module_key8
module_key9

module_key10
# module_key11
# module_key12
module_key13
module_key14
```python
import sys

while True:
    print('Type exit to exit.')
    response = input()
    if response == 'exit':
        sys.exit()
    print('You typed ' + response + '.')
```
module_key15