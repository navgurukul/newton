```ngMeta
flow_control_key1
```
# flow_control_key2
flow_control_key3
# flow_control_key4
flow_control_key5
flow_control_key6```python
name = 'Mary'
password = 'swordfish'
if name == 'Mary':
    print('Hello Mary')
    if password == 'swordfish':
        print('Access granted.')
    else:
        print('Wrong password.')
```
flow_control_key7
# flow_control_key8
flow_control_key9
flow_control_key10
