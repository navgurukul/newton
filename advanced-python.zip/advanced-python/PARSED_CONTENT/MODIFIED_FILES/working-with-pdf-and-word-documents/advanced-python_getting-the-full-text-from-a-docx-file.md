```ngMeta
getting-the-full-text-from-a-docx-file_key1
```
# getting-the-full-text-from-a-docx-file_key2
getting-the-full-text-from-a-docx-file_key3

getting-the-full-text-from-a-docx-file_key4
getting-the-full-text-from-a-docx-file_key5
getting-the-full-text-from-a-docx-file_key6
```python
>>> import readDocx
>>> print(readDocx.getText('demo.docx'))
```
getting-the-full-text-from-a-docx-file_key7

getting-the-full-text-from-a-docx-file_key8

getting-the-full-text-from-a-docx-file_key9
# getting-the-full-text-from-a-docx-file_key10
getting-the-full-text-from-a-docx-file_key11
getting-the-full-text-from-a-docx-file_key12
getting-the-full-text-from-a-docx-file_key13
getting-the-full-text-from-a-docx-file_key14
getting-the-full-text-from-a-docx-file_key15
getting-the-full-text-from-a-docx-file_key16
getting-the-full-text-from-a-docx-file_key17
getting-the-full-text-from-a-docx-file_key18
getting-the-full-text-from-a-docx-file_key19
getting-the-full-text-from-a-docx-file_key20
getting-the-full-text-from-a-docx-file_key21
getting-the-full-text-from-a-docx-file_key22
getting-the-full-text-from-a-docx-file_key23
getting-the-full-text-from-a-docx-file_key24
 
getting-the-full-text-from-a-docx-file_key25
getting-the-full-text-from-a-docx-file_key26
getting-the-full-text-from-a-docx-file_key27
