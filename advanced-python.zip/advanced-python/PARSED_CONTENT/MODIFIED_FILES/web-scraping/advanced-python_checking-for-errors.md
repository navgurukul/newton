```ngMeta
checking-for-errors_key1
```
# checking-for-errors_key2
checking-for-errors_key3
```python
>>> res = requests.get('http://inventwithpython.com/page_that_does_not_exist')
>>> res.raise_for_status()
```
checking-for-errors_key4checking-for-errors_key5

checking-for-errors_key6checking-for-errors_key7checking-for-errors_key8

checking-for-errors_key9