```ngMeta
controlling-the-browser-with-the-selenium-module_key1
```
# controlling-the-browser-with-the-selenium-module_key2
controlling-the-browser-with-the-selenium-module_key3
controlling-the-browser-with-the-selenium-module_key4
# controlling-the-browser-with-the-selenium-module_key5
controlling-the-browser-with-the-selenium-module_key6controlling-the-browser-with-the-selenium-module_key7
controlling-the-browser-with-the-selenium-module_key8
```python
>>> from selenium import webdriver
>>> browser = webdriver.Firefox()
>>> type(browser)
```
controlling-the-browser-with-the-selenium-module_key9```python
>>> browser.get('http://inventwithpython.com')
```
controlling-the-browser-with-the-selenium-module_key10controlling-the-browser-with-the-selenium-module_key11controlling-the-browser-with-the-selenium-module_key12controlling-the-browser-with-the-selenium-module_key13controlling-the-browser-with-the-selenium-module_key14```python
<<<<<<< HEAD
```
```python
=======
```
```python
>>>>>>> e7c92b8136151bdc6c9b42ea47eaf1dc7cfdbe70
```
controlling-the-browser-with-the-selenium-module_key15
