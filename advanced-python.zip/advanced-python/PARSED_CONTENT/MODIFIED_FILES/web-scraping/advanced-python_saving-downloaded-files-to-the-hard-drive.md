```ngMeta
saving-downloaded-files-to-the-hard-drive_key1
```
# saving-downloaded-files-to-the-hard-drive_key2
saving-downloaded-files-to-the-hard-drive_key3
saving-downloaded-files-to-the-hard-drive_key4
saving-downloaded-files-to-the-hard-drive_key5
saving-downloaded-files-to-the-hard-drive_key6saving-downloaded-files-to-the-hard-drive_key7
saving-downloaded-files-to-the-hard-drive_key8saving-downloaded-files-to-the-hard-drive_key9
saving-downloaded-files-to-the-hard-drive_key10
```python
>>> import requests
>>> res = requests.get('https://automatetheboringstuff.com/files/rj.txt')
>>> res.raise_for_status()
>>> playFile = open('RomeoAndJuliet.txt', 'wb')
>>> for chunk in res.iter_content(100000):
        playFile.write(chunk)
```
saving-downloaded-files-to-the-hard-drive_key11```python
>>> playFile.close()
```
saving-downloaded-files-to-the-hard-drive_key12
saving-downloaded-files-to-the-hard-drive_key13
saving-downloaded-files-to-the-hard-drive_key14
saving-downloaded-files-to-the-hard-drive_key15
saving-downloaded-files-to-the-hard-drive_key16
saving-downloaded-files-to-the-hard-drive_key17
saving-downloaded-files-to-the-hard-drive_key18
saving-downloaded-files-to-the-hard-drive_key19
saving-downloaded-files-to-the-hard-drive_key20
saving-downloaded-files-to-the-hard-drive_key21saving-downloaded-files-to-the-hard-drive_key22