```ngMeta
fetching-an-email-and-marking-it-as-read_key1
```
# fetching-an-email-and-marking-it-as-read_key2
fetching-an-email-and-marking-it-as-read_key3
fetching-an-email-and-marking-it-as-read_key4
fetching-an-email-and-marking-it-as-read_key5
```python
>>> rawMessages = imapObj.fetch(UIDs, ['BODY[]'])
>>> import pprint
>>> pprint.pprint(rawMessages)
```
fetching-an-email-and-marking-it-as-read_key6[fetching-an-email-and-marking-it-as-read_key7](mailto:&#x6d;&#x79;&#95;&#101;&#109;&#97;&#x69;&#108;&#x5f;&#x61;&#100;&#x64;&#114;&#x65;&#x73;&#x73;&#64;&#x67;&#x6d;&#97;&#x69;&#x6c;&#x2e;&#x63;&#x6f;&#x6d;)
fetching-an-email-and-marking-it-as-read_key8```python
>>> imapObj.select_folder('INBOX', readonly=False)
```
