```ngMeta
sending-an-email_key1
```
# sending-an-email_key2
sending-an-email_key3
```python
>>> smtpObj.sendmail(' my_email_address@gmail.com ', ' recipient@example.com ','Subject: So long.\nDear Alice,so long and thanks for all the fish. Sincerely,Bob')
```
sending-an-email_key4
sending-an-email_key5
sending-an-email_key6
sending-an-email_key7
sending-an-email_key8
sending-an-email_key9# sending-an-email_key10
sending-an-email_key11
```python
>>> smtpObj.quit()
```
sending-an-email_key12
sending-an-email_key13