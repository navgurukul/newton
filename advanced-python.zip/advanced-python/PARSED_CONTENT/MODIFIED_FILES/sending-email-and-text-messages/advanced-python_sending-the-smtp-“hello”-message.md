```ngMeta
sending-the-smtp-“hello”-message_key1
```
# sending-the-smtp-“hello”-message_key2
sending-the-smtp-“hello”-message_key3
```python
>>> smtpObj.ehlo()
```
sending-the-smtp-“hello”-message_key4sending-the-smtp-“hello”-message_key5# sending-the-smtp-“hello”-message_key6
sending-the-smtp-“hello”-message_key7
sending-the-smtp-“hello”-message_key8
```python
>>> smtpObj.starttls()
```
sending-the-smtp-“hello”-message_key9
