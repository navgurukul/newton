```ngMeta
logging-in-to-the-smtp-server_key1
```
# logging-in-to-the-smtp-server_key2
logging-in-to-the-smtp-server_key3
```python
>>> smtpObj.login(' my_email_address@gmail.com ', ' MY_SECRET_PASSWORD ')
```
logging-in-to-the-smtp-server_key4
logging-in-to-the-smtp-server_key5logging-in-to-the-smtp-server_key6logging-in-to-the-smtp-server_key7
logging-in-to-the-smtp-server_key8
# logging-in-to-the-smtp-server_key9
logging-in-to-the-smtp-server_key10