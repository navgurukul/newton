```ngMeta
disconnecting-from-the-imap-server_key1
```
# disconnecting-from-the-imap-server_key2
disconnecting-from-the-imap-server_key3
```python
>>> imapObj.logout()
```
disconnecting-from-the-imap-server_key4

disconnecting-from-the-imap-server_key5
disconnecting-from-the-imap-server_key6
