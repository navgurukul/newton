```ngMeta
connecting-to-an-imap-server_key1
```
# connecting-to-an-imap-server_key2
connecting-to-an-imap-server_key3
connecting-to-an-imap-server_key4
connecting-to-an-imap-server_key5
connecting-to-an-imap-server_key6
connecting-to-an-imap-server_key7
connecting-to-an-imap-server_key8
connecting-to-an-imap-server_key9
connecting-to-an-imap-server_key10
connecting-to-an-imap-server_key11
connecting-to-an-imap-server_key12
```python
>>> import imapclient
>>> imapObj = imapclient.IMAPClient('imap.gmail.com', ssl=True)
```
connecting-to-an-imap-server_key13
# connecting-to-an-imap-server_key14
connecting-to-an-imap-server_key15
```python
>>> imapObj.login(' my_email_address@gmail.com ', ' MY_SECRET_PASSWORD ')
```
connecting-to-an-imap-server_key16connecting-to-an-imap-server_key17connecting-to-an-imap-server_key18
## connecting-to-an-imap-server_key19
connecting-to-an-imap-server_key20
connecting-to-an-imap-server_key21