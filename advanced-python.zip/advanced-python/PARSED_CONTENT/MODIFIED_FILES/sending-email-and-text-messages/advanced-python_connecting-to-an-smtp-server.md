```ngMeta
connecting-to-an-smtp-server_key1
```
# connecting-to-an-smtp-server_key2
connecting-to-an-smtp-server_key3connecting-to-an-smtp-server_key4
connecting-to-an-smtp-server_key5
connecting-to-an-smtp-server_key6
connecting-to-an-smtp-server_key7
connecting-to-an-smtp-server_key8
connecting-to-an-smtp-server_key9
connecting-to-an-smtp-server_key10
connecting-to-an-smtp-server_key11
connecting-to-an-smtp-server_key12
connecting-to-an-smtp-server_key13
connecting-to-an-smtp-server_key14```python
>>> smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
>>> type(smtpObj)
```
connecting-to-an-smtp-server_key15
```python
>>> smtpObj = smtplib.SMTP_SSL('smtp.gmail.com', 465)
```
# connecting-to-an-smtp-server_key16
connecting-to-an-smtp-server_key17
connecting-to-an-smtp-server_key18