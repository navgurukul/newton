```ngMeta
workbooks-sheets-cells_key1
```
# workbooks-sheets-cells_key2
workbooks-sheets-cells_key3
workbooks-sheets-cells_key4
workbooks-sheets-cells_key5
workbooks-sheets-cells_key6
workbooks-sheets-cells_key7
workbooks-sheets-cells_key8
workbooks-sheets-cells_key9
workbooks-sheets-cells_key10
workbooks-sheets-cells_key11# workbooks-sheets-cells_key12
workbooks-sheets-cells_key13workbooks-sheets-cells_key14workbooks-sheets-cells_key15
workbooks-sheets-cells_key16
workbooks-sheets-cells_key17
workbooks-sheets-cells_key18
workbooks-sheets-cells_key19
workbooks-sheets-cells_key20
workbooks-sheets-cells_key21
workbooks-sheets-cells_key22
workbooks-sheets-cells_key23
workbooks-sheets-cells_key24
workbooks-sheets-cells_key25
workbooks-sheets-cells_key26
workbooks-sheets-cells_key27
# workbooks-sheets-cells_key28
workbooks-sheets-cells_key29
workbooks-sheets-cells_key30

workbooks-sheets-cells_key31 workbooks-sheets-cells_key32
 workbooks-sheets-cells_key33
workbooks-sheets-cells_key34
 workbooks-sheets-cells_key35
workbooks-sheets-cells_key36
 workbooks-sheets-cells_key37
workbooks-sheets-cells_key38
workbooks-sheets-cells_key39
# workbooks-sheets-cells_key40
workbooks-sheets-cells_key41

workbooks-sheets-cells_key42
```python
>>> countyData['AK']['Anchorage']['pop']
```
workbooks-sheets-cells_key43```python
>>> countyData['AK']['Anchorage']['tracts']
```
workbooks-sheets-cells_key44

workbooks-sheets-cells_key45

workbooks-sheets-cells_key46 workbooks-sheets-cells_key47
 workbooks-sheets-cells_key48
workbooks-sheets-cells_key49
workbooks-sheets-cells_key50
workbooks-sheets-cells_key51
 workbooks-sheets-cells_key52
workbooks-sheets-cells_key53
workbooks-sheets-cells_key54
workbooks-sheets-cells_key55
workbooks-sheets-cells_key56
# workbooks-sheets-cells_key57
workbooks-sheets-cells_key58

workbooks-sheets-cells_key59 workbooks-sheets-cells_key60
 workbooks-sheets-cells_key61
workbooks-sheets-cells_key62
workbooks-sheets-cells_key63
# workbooks-sheets-cells_key64
workbooks-sheets-cells_key65
```python
>>> import os
>>> os.chdir('C:\\Python34')
>>> import census2010
>>> census2010.allData['AK']['Anchorage']
```
workbooks-sheets-cells_key66```python
>>> anchoragePop = census2010.allData['AK']['Anchorage']['pop']
>>> print('The 2010 population of Anchorage was ' + str(anchoragePop))
```
workbooks-sheets-cells_key67
workbooks-sheets-cells_key68workbooks-sheets-cells_key69workbooks-sheets-cells_key70# workbooks-sheets-cells_key71
workbooks-sheets-cells_key72
workbooks-sheets-cells_key73
workbooks-sheets-cells_key74
workbooks-sheets-cells_key75
workbooks-sheets-cells_key76



