```ngMeta
opening-excel-documents-with-openpyxl_key1
```
# opening-excel-documents-with-openpyxl_key2
opening-excel-documents-with-openpyxl_key3
```python
>>> import openpyxl
>>> wb = openpyxl.load_workbook('example.xlsx')
>>> type(wb)
```
opening-excel-documents-with-openpyxl_key4
opening-excel-documents-with-openpyxl_key5