```ngMeta
assertions_key1
```
# assertions_key2
assertions_key3
assertions_key4
assertions_key5
assertions_key6
assertions_key7
assertions_key8
```python
>>> podBayDoorStatus = 'open'
>>> assert podBayDoorStatus == 'open', 'The pod bay doors need to be "open".'
>>> podBayDoorStatus = 'I\'m sorry, Dave. I\'m afraid I can\'t do that.'
>>> assert podBayDoorStatus == 'open', 'The pod bay doors need to be "open".'
```
assertions_key9assertions_key10
assertions_key11
assertions_key12
assertions_key13