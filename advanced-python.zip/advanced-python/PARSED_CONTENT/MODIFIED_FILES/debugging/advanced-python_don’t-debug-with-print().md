```ngMeta
don’t-debug-with-print()_key1
```
# don’t-debug-with-print()_key2
don’t-debug-with-print()_key3
don’t-debug-with-print()_key4
# don’t-debug-with-print()_key5
don’t-debug-with-print()_key6
don’t-debug-with-print()_key7
don’t-debug-with-print()_key8
don’t-debug-with-print()_key9
don’t-debug-with-print()_key10
don’t-debug-with-print()_key11
don’t-debug-with-print()_key12
don’t-debug-with-print()_key13
don’t-debug-with-print()_key14
don’t-debug-with-print()_key15
don’t-debug-with-print()_key16
don’t-debug-with-print()_key17
don’t-debug-with-print()_key18
don’t-debug-with-print()_key19
don’t-debug-with-print()_key20
don’t-debug-with-print()_key21
don’t-debug-with-print()_key22
don’t-debug-with-print()_key23
don’t-debug-with-print()_key24
don’t-debug-with-print()_key25
don’t-debug-with-print()_key26
```python
>>> import logging
>>> logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s -'
%(levelname)s - %(message)s')'
>>> logging.debug('Some debugging details.')
```
don’t-debug-with-print()_key27```python
>>> logging.info('The logging module is working.')
```
don’t-debug-with-print()_key28```python
>>> logging.warning('An error message is about to be logged.')
```
don’t-debug-with-print()_key29```python
>>> logging.error('An error has occurred.')
```
don’t-debug-with-print()_key30```python
>>> logging.critical('The program is unable to recover!')
```
don’t-debug-with-print()_key31
