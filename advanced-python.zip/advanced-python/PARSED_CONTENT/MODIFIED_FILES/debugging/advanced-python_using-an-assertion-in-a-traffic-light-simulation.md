```ngMeta
using-an-assertion-in-a-traffic-light-simulation_key1
```
# using-an-assertion-in-a-traffic-light-simulation_key2
using-an-assertion-in-a-traffic-light-simulation_key3

using-an-assertion-in-a-traffic-light-simulation_key4
using-an-assertion-in-a-traffic-light-simulation_key5

using-an-assertion-in-a-traffic-light-simulation_key6
using-an-assertion-in-a-traffic-light-simulation_key7
using-an-assertion-in-a-traffic-light-simulation_key8
using-an-assertion-in-a-traffic-light-simulation_key9

using-an-assertion-in-a-traffic-light-simulation_key10

using-an-assertion-in-a-traffic-light-simulation_key11using-an-assertion-in-a-traffic-light-simulation_key12
