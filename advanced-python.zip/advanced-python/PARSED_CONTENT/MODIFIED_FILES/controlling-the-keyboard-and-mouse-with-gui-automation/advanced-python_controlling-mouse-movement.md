```ngMeta
controlling-mouse-movement_key1
```
# controlling-mouse-movement_key2
controlling-mouse-movement_key3
controlling-mouse-movement_key4
controlling-mouse-movement_key5
controlling-mouse-movement_key6
controlling-mouse-movement_key7
```python
>>> import pyautogui
>>> pyautogui.size()
```
controlling-mouse-movement_key8```python
>>> width, height = pyautogui.size()
```
controlling-mouse-movement_key9
