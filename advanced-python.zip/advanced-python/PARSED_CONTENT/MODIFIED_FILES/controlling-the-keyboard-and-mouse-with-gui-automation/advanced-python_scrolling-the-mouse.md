```ngMeta
scrolling-the-mouse_key1
```
# scrolling-the-mouse_key2
scrolling-the-mouse_key3
```python
>>> pyautogui.scroll(200)
```
scrolling-the-mouse_key4
```python
>>> import pyperclip
>>> numbers = ''
>>> for i in range(200):
      numbers = numbers + str(i) + '\n'

>>> pyperclip.copy(numbers)
```
scrolling-the-mouse_key5
```python
>>> import time, pyautogui
>>> time.sleep(5); pyautogui.scroll(100)
```
scrolling-the-mouse_key6
scrolling-the-mouse_key7
