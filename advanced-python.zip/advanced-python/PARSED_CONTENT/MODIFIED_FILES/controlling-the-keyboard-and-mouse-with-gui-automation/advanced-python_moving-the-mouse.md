```ngMeta
moving-the-mouse_key1
```
# moving-the-mouse_key2
moving-the-mouse_key3
```python
>>> import pyautogui
>>> for i in range(10):
```
moving-the-mouse_key4
moving-the-mouse_key5
```python
>>> import pyautogui
>>> for i in range(10):
```
moving-the-mouse_key6# moving-the-mouse_key7
moving-the-mouse_key8
```python
>>> pyautogui.position()
```
moving-the-mouse_key9```python
>>> pyautogui.position()
```
moving-the-mouse_key10```python
>>> pyautogui.position()
```
moving-the-mouse_key11