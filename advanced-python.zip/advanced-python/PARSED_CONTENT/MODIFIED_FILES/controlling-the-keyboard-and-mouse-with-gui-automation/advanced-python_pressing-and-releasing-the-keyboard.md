```ngMeta
pressing-and-releasing-the-keyboard_key1
```
# pressing-and-releasing-the-keyboard_key2
pressing-and-releasing-the-keyboard_key3
pressing-and-releasing-the-keyboard_key4
```python
>>> pyautogui.keyDown('shift'); pyautogui.press('4'); pyautogui.keyUp('shift')
```
pressing-and-releasing-the-keyboard_key5
pressing-and-releasing-the-keyboard_key6

pressing-and-releasing-the-keyboard_key7

pressing-and-releasing-the-keyboard_key8
pressing-and-releasing-the-keyboard_key9
```python
   >>> import pyautogui, time
   >>> def commentAfterDelay():
❶       pyautogui.click(100, 100)
❷       pyautogui.typewrite('In IDLE, Alt-3 comments out a line.')
         time.sleep(2)
❸       pyautogui.hotkey('alt', '3')

   >>> commentAfterDelay()
```
pressing-and-releasing-the-keyboard_key10
