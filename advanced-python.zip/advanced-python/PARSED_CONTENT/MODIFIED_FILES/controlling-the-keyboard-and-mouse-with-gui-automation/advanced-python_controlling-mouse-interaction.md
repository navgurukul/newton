```ngMeta
controlling-mouse-interaction_key1
```
# controlling-mouse-interaction_key2
controlling-mouse-interaction_key3
# controlling-mouse-interaction_key4
controlling-mouse-interaction_key5
controlling-mouse-interaction_key6
controlling-mouse-interaction_key7
```python
>>> import pyautogui
>>> pyautogui.click(10, 5)
```
controlling-mouse-interaction_key8
controlling-mouse-interaction_key9
