```ngMeta
controlling-the-keyboard_key1
```
# controlling-the-keyboard_key2
controlling-the-keyboard_key3
# controlling-the-keyboard_key4
controlling-the-keyboard_key5
controlling-the-keyboard_key6
```python
>>> pyautogui.click(100, 100); pyautogui.typewrite('Hello world!')
```
controlling-the-keyboard_key7
controlling-the-keyboard_key8
controlling-the-keyboard_key9
controlling-the-keyboard_key10
controlling-the-keyboard_key11