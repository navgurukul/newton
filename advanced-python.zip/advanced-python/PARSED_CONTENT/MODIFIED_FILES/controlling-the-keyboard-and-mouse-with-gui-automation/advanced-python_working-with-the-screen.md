```ngMeta
working-with-the-screen_key1
```
# working-with-the-screen_key2
working-with-the-screen_key3
working-with-the-screen_key4
# working-with-the-screen_key5
working-with-the-screen_key6
```python
>>> import pyautogui
>>> im = pyautogui.screenshot()
```
working-with-the-screen_key7
```python
>>> im.getpixel((0, 0))
```
working-with-the-screen_key8```python
>>> im.getpixel((50, 200))
```
working-with-the-screen_key9
