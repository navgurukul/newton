```ngMeta
project-where-is-the-mouse-right-now_key1
```
# project-where-is-the-mouse-right-now_key2
project-where-is-the-mouse-right-now_key3
project-where-is-the-mouse-right-now_key4
project-where-is-the-mouse-right-now_key5
project-where-is-the-mouse-right-now_key6
project-where-is-the-mouse-right-now_key7
project-where-is-the-mouse-right-now_key8
project-where-is-the-mouse-right-now_key9
project-where-is-the-mouse-right-now_key10
project-where-is-the-mouse-right-now_key11
# project-where-is-the-mouse-right-now_key12
project-where-is-the-mouse-right-now_key13

project-where-is-the-mouse-right-now_key14# project-where-is-the-mouse-right-now_key15
project-where-is-the-mouse-right-now_key16
# project-where-is-the-mouse-right-now_key17
project-where-is-the-mouse-right-now_key18

project-where-is-the-mouse-right-now_key19 project-where-is-the-mouse-right-now_key20
project-where-is-the-mouse-right-now_key21```python
   try:
       while True:
           # TODO: Get and print the mouse coordinates.
❶ except KeyboardInterrupt:
❷     print('\nDone.')
```
project-where-is-the-mouse-right-now_key22
# project-where-is-the-mouse-right-now_key23
project-where-is-the-mouse-right-now_key24

project-where-is-the-mouse-right-now_key25# project-where-is-the-mouse-right-now_key26
project-where-is-the-mouse-right-now_key27```python
        # Get and print the mouse coordinates.
        x, y = pyautogui.position()
        positionStr = 'X: ' + str(x).rjust(4) + ' Y: ' + str(y).rjust(4)
```
project-where-is-the-mouse-right-now_key28
project-where-is-the-mouse-right-now_key29

project-where-is-the-mouse-right-now_key30 project-where-is-the-mouse-right-now_key31
project-where-is-the-mouse-right-now_key32```python
           print(positionStr, end='')
❶         print('\b' * len(positionStr), end='', flush=True)
```
project-where-is-the-mouse-right-now_key33
project-where-is-the-mouse-right-now_key34
project-where-is-the-mouse-right-now_key35
project-where-is-the-mouse-right-now_key36
project-where-is-the-mouse-right-now_key37

project-where-is-the-mouse-right-now_key38
