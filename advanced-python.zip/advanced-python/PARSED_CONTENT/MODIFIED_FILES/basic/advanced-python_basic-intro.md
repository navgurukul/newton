```ngMeta
basic-intro_key1
```
# basic-intro_key2
basic-intro_key3
basic-intro_key4
# basic-intro_key5
basic-intro_key6
basic-intro_key7```python
>>> 2 + 2
```
basic-intro_key8

basic-intro_key9```python
Type "copyright", "credits" or "license()" for more information.
>>> 2 + 2
```
basic-intro_key10```python
>>>
```
basic-intro_key11
basic-intro_key12
```python
>>> 2
```
basic-intro_key13
basic-intro_key14
basic-intro_key15basic-intro_key16basic-intro_key17
basic-intro_key18
basic-intro_key19
|basic-intro_key20|basic-intro_key21|basic-intro_key22|
|---|---|---|
|basic-intro_key23|basic-intro_key24|basic-intro_key25|
|basic-intro_key26|basic-intro_key27|basic-intro_key28|
|basic-intro_key29|basic-intro_key30|basic-intro_key31|
|basic-intro_key32|basic-intro_key33|basic-intro_key34|
|basic-intro_key35|basic-intro_key36|basic-intro_key37|
|basic-intro_key38|basic-intro_key39|basic-intro_key40|
basic-intro_key41

```python
>>> 2 + 3 * 6
```
basic-intro_key42```python
>>> (2 + 3) * 6
```
basic-intro_key43```python
>>> 48565878 * 578453
```
basic-intro_key44```python
>>> 2 ** 8
```
basic-intro_key45```python
>>> 23 / 7
```
basic-intro_key46```python
>>> 23 // 7
```
basic-intro_key47```python
>>> 23 % 7
```
basic-intro_key48```python
>>> 2     +            2
```
basic-intro_key49```python
>>> (5 - 1) * ((7 + 1) / (3 - 1))
```
basic-intro_key50


basic-intro_key51
basic-intro_key52
basic-intro_key53
basic-intro_key54
```python
>>> 5 +
  File "<stdin>", line 1
    5 +
      ^
SyntaxError: invalid syntax
>>> 42 + 5 + * 2
  File "<stdin>", line 1
    42 + 5 + * 2
             ^
SyntaxError: invalid syntax
```
basic-intro_key55
# basic-intro_key56
basic-intro_key57
basic-intro_key58
|basic-intro_key59|basic-intro_key60|
|---|---|
|basic-intro_key61|basic-intro_key62|
|basic-intro_key63|basic-intro_key64|
|basic-intro_key65|basic-intro_key66|
basic-intro_key67
basic-intro_key68
# basic-intro_key69
basic-intro_key70
```python
>>> 'Alice' + 'Bob'
```
basic-intro_key71
```python
>>> 'Alice' + 42
```
basic-intro_key72basic-intro_key73
basic-intro_key74
```python
>>> 'Alice' * 5
```
basic-intro_key75
basic-intro_key76
```python
>>> 'Alice' * 'Bob'
```
basic-intro_key77basic-intro_key78```python
>>> 'Alice' * 5.0
```
basic-intro_key79basic-intro_key80
>>> basic-intro_key81
basic-intro_key82
# basic-intro_key83
|basic-intro_key84|basic-intro_key85|
|---|---|
|basic-intro_key86|basic-intro_key87|
|basic-intro_key88|basic-intro_key89|
|basic-intro_key90|basic-intro_key91|
|basic-intro_key92|basic-intro_key93|
|basic-intro_key94|basic-intro_key95|
|basic-intro_key96|basic-intro_key97|
basic-intro_key98
basic-intro_key99
basic-intro_key100
basic-intro_key101
basic-intro_key102
basic-intro_key103
basic-intro_key104
basic-intro_key105
basic-intro_key106
basic-intro_key107
basic-intro_key108

basic-intro_key109
basic-intro_key110```python
>>> ================================ RESTART ================================
>>>
```
basic-intro_key111```python
>>>
```
basic-intro_key112
basic-intro_key113
# basic-intro_key114
basic-intro_key115

basic-intro_key116
basic-intro_key117
basic-intro_key118
basic-intro_key119

basic-intro_key120
basic-intro_key121
basic-intro_key122

basic-intro_key123
basic-intro_key124

basic-intro_key125
```python
>>> len('hello')
```
basic-intro_key126```python
>>> len('My very energetic monster just scarfed nachos.')
```
basic-intro_key127```python
>>> len('')
```
basic-intro_key128

>>> basic-intro_key129
```python
>>> 'I am ' + 29 + ' years old.'
```
basic-intro_key130basic-intro_key131
basic-intro_key132
```python
>>> str(29)
```
basic-intro_key133```python
>>> print('I am ' + str(29) + ' years old.')
```
basic-intro_key134
basic-intro_key135
```python
>>> str(0)
```
basic-intro_key136```python
>>> str(-3.14)
```
basic-intro_key137```python
>>> int('42')
```
basic-intro_key138```python
>>> int('-99')
```
basic-intro_key139```python
>>> int(1.25)
```
basic-intro_key140```python
>>> int(1.99)
```
basic-intro_key141```python
>>> float('3.14')
```
basic-intro_key142```python
>>> float(10)
```
basic-intro_key143
basic-intro_key144
```python
>>> spam = input()
```
basic-intro_key145```python
>>> spam
```
basic-intro_key146
```python
>>> spam = int(spam)
>>> spam
```
basic-intro_key147
```python
>>> spam * 10 / 5
```
basic-intro_key148
```python
>>> int('99.99')
```
basic-intro_key149basic-intro_key150```python
>>> int('twelve')
```
basic-intro_key151basic-intro_key152
```python
>>> int(7.7)
```
basic-intro_key153```python
>>> int(7.7) + 1
```
basic-intro_key154

basic-intro_key155
basic-intro_key156
basic-intro_key157
basic-intro_key158
basic-intro_key159
```python
>>> 42 == '42'
```
basic-intro_key160```python
>>> 42 == 42.0
```
basic-intro_key161```python
>>> 42.0 == 0042.000
```
basic-intro_key162
# basic-intro_key163
basic-intro_key164
basic-intro_key165
basic-intro_key166
basic-intro_key167
basic-intro_key168
basic-intro_key169
basic-intro_key170
basic-intro_key171
basic-intro_key172
basic-intro_key173
basic-intro_key174



