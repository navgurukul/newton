```ngMeta
list-to-dictionary-function-for-fantasy-game-inventory_key1
```
# list-to-dictionary-function-for-fantasy-game-inventory_key2
list-to-dictionary-function-for-fantasy-game-inventory_key3

list-to-dictionary-function-for-fantasy-game-inventory_key4

list-to-dictionary-function-for-fantasy-game-inventory_key5```python
inv = {'gold coin': 42, 'rope': 1}
dragonLoot = ['gold coin', 'dagger', 'gold coin', 'gold coin', 'ruby']
inv = addToInventory(inv, dragonLoot)
displayInventory(inv)
```
list-to-dictionary-function-for-fantasy-game-inventory_key6

list-to-dictionary-function-for-fantasy-game-inventory_key7
list-to-dictionary-function-for-fantasy-game-inventory_key8