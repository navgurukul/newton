```ngMeta
practice-questions_key1
```
# practice-questions_key2
practice-questions_key3
practice-questions_key4
practice-questions_key5
practice-questions_key6
practice-questions_key7
practice-questions_key8
practice-questions_key9
practice-questions_key10
# practice-questions_key11
practice-questions_key12
# practice-questions_key13
practice-questions_key14
practice-questions_key15

practice-questions_key16

# practice-questions_key17
```python
stuff = {'rope': 1, 'torch': 6, 'gold coin': 42, 'dagger': 1, 'arrow': 12}

def displayInventory(inventory):
    print("Inventory:")
    item_total = 0
    for k, v in inventory.items():
        # FILL IN THE CODE HERE
    print("Total number of items: " + str(item_total))

displayInventory(stuff)
```
