```ngMeta
function-introduction_key1
```
function-introduction_key2
function-introduction_key3
```python
❶ def hello():
❷     print('Howdy!')
       print('Howdy!!!')
       print('Hello there.')
❸ hello()
   hello()
   hello()
```
function-introduction_key4
function-introduction_key5
function-introduction_key6

function-introduction_key7
function-introduction_key8
```python
print('Howdy!')
print('Howdy!!!')
print('Hello there.')
print('Howdy!')
print('Howdy!!!')
print('Hello there.')
print('Howdy!')
print('Howdy!!!')
print('Hello there.')
```
function-introduction_key9
function-introduction_key10





