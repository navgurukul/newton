```ngMeta
local-and-global-scope_key1
```
# local-and-global-scope_key2
local-and-global-scope_key3
local-and-global-scope_key4
local-and-global-scope_key5
local-and-global-scope_key6
local-and-global-scope_key7
local-and-global-scope_key8
local-and-global-scope_key9
local-and-global-scope_key10
local-and-global-scope_key11
local-and-global-scope_key12