```ngMeta
global-variables-can-be-read-from-a-local-scope_key1
```
# global-variables-can-be-read-from-a-local-scope_key2
global-variables-can-be-read-from-a-local-scope_key3

global-variables-can-be-read-from-a-local-scope_key4