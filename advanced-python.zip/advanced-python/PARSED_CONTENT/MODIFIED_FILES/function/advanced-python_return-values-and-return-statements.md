```ngMeta
return-values-and-return-statements_key1
```
# return-values-and-return-statements_key2
return-values-and-return-statements_key3
return-values-and-return-statements_key4
return-values-and-return-statements_key5
return-values-and-return-statements_key6
return-values-and-return-statements_key7
```python
❶ import random
❷ def getAnswer(answerNumber):
❸     if answerNumber == 1:
           return 'It is certain'
       elif answerNumber == 2:
           return 'It is decidedly so'
       elif answerNumber == 3:
           return 'Yes'
       elif answerNumber == 4:
           return 'Reply hazy try again'
       elif answerNumber == 5:
           return 'Ask again later'
       elif answerNumber == 6:
           return 'Concentrate and ask again'
       elif answerNumber == 7:
           return 'My reply is no'
       elif answerNumber == 8:
           return 'Outlook not so good'
       elif answerNumber == 9:
           return 'Very doubtful'
```
return-values-and-return-statements_key8
return-values-and-return-statements_key9
return-values-and-return-statements_key10

return-values-and-return-statements_key11

return-values-and-return-statements_key12
# return-values-and-return-statements_key13
return-values-and-return-statements_key14
return-values-and-return-statements_key15
```python
>>> spam = print('Hello!')
```
return-values-and-return-statements_key16```python
>>> None == spam
```
return-values-and-return-statements_key17