```ngMeta
local-variables-cannot-be-used-in-the-global-scope_key1
```
# local-variables-cannot-be-used-in-the-global-scope_key2
local-variables-cannot-be-used-in-the-global-scope_key3
```python
def spam():
    eggs = 31337
spam()
print(eggs)
```
local-variables-cannot-be-used-in-the-global-scope_key4
```python
Traceback (most recent call last):
  File "C:/test3784.py", line 4, in <module>
    print(eggs)
NameError: name 'eggs' is not defined
```
local-variables-cannot-be-used-in-the-global-scope_key5