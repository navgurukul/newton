```ngMeta
function_define_key1
```
# function_define_key2
function_define_key3
```python
❶ def hello(name):
❷     print('Hello ' + name)

❸ hello('Alice')
  hello('Bob')
```
function_define_key4

function_define_key5
function_define_key6
function_define_key7