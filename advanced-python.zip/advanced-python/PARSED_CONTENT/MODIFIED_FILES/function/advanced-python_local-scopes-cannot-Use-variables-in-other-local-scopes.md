```ngMeta
local-scopes-cannot-Use-variables-in-other-local-scopes_key1
```
# local-scopes-cannot-Use-variables-in-other-local-scopes_key2
local-scopes-cannot-Use-variables-in-other-local-scopes_key3

local-scopes-cannot-Use-variables-in-other-local-scopes_key4
local-scopes-cannot-Use-variables-in-other-local-scopes_key5
local-scopes-cannot-Use-variables-in-other-local-scopes_key6
local-scopes-cannot-Use-variables-in-other-local-scopes_key7
local-scopes-cannot-Use-variables-in-other-local-scopes_key8