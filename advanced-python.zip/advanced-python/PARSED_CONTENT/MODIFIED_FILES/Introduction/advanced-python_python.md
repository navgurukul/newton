```ngMeta
python_key1
```
# python_key2
python_key3[python_key4](http://python.org/)
python_key5
python_key6
# python_key7
python_key8
python_key9

python_key10

# python_key11
python_key12
python_key13
# python_key14
python_key15[python_key16](http://stackoverflow.com/)
python_key17[python_key18](http://reddit.com/r/learnprogramming/)
python_key19
## python_key20
python_key21
# python_key22
python_key23
```python
  >>> '42' + 3
❶ Traceback (most recent call last):
    File "<pyshell#0>", line 1, in <module>
      '42' + 3
❷ """TypeError: Can't convert 'int' object to str "implicitly"""
  >>>
```
python_key24

python_key25
python_key26
