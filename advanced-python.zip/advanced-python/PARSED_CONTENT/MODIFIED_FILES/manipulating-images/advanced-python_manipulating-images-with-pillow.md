```ngMeta
manipulating-images-with-pillow_key1
```
# manipulating-images-with-pillow_key2
manipulating-images-with-pillow_key3manipulating-images-with-pillow_key4manipulating-images-with-pillow_key5
manipulating-images-with-pillow_key6
```python
>>> from PIL import Image
>>> catIm = Image.open('zophie.png')
```
manipulating-images-with-pillow_key7
manipulating-images-with-pillow_key8
manipulating-images-with-pillow_key9
```python
>>> import os
>>> os.chdir('C:\\folder_with_image_file')
```
manipulating-images-with-pillow_key10
manipulating-images-with-pillow_key11
