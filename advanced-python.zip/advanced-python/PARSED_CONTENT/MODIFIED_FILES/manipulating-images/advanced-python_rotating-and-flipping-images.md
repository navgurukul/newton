```ngMeta
rotating-and-flipping-images_key1
```
# rotating-and-flipping-images_key2
rotating-and-flipping-images_key3
```python
>>> catIm.rotate(90).save('rotated90.png')
>>> catIm.rotate(180).save('rotated180.png')
>>> catIm.rotate(270).save('rotated270.png')
```
rotating-and-flipping-images_key4
rotating-and-flipping-images_key5
rotating-and-flipping-images_key6
rotating-and-flipping-images_key7

>>> rotating-and-flipping-images_key8
rotating-and-flipping-images_key9
rotating-and-flipping-images_key10

>>> rotating-and-flipping-images_key11
rotating-and-flipping-images_key12
