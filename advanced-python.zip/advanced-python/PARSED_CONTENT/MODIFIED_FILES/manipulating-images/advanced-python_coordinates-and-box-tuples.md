```ngMeta
coordinates-and-box-tuples_key1
```
# coordinates-and-box-tuples_key2
coordinates-and-box-tuples_key3
coordinates-and-box-tuples_key4
coordinates-and-box-tuples_key5
coordinates-and-box-tuples_key6
coordinates-and-box-tuples_key7
coordinates-and-box-tuples_key8
coordinates-and-box-tuples_key9
coordinates-and-box-tuples_key10
coordinates-and-box-tuples_key11