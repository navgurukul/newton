```ngMeta
colors-and-rgba-values_key1
```
# colors-and-rgba-values_key2
colors-and-rgba-values_key3
colors-and-rgba-values_key4
colors-and-rgba-values_key5
colors-and-rgba-values_key6
colors-and-rgba-values_key7
colors-and-rgba-values_key8
colors-and-rgba-values_key9
colors-and-rgba-values_key10
colors-and-rgba-values_key11
colors-and-rgba-values_key12
colors-and-rgba-values_key13
## colors-and-rgba-values_key14
colors-and-rgba-values_key15
colors-and-rgba-values_key16
colors-and-rgba-values_key17
```python
❶ >>> from PIL import ImageColor
❷ >>> ImageColor.getcolor('red', 'RGBA')
   (255, 0, 0, 255)
❸ >>> ImageColor.getcolor('RED', 'RGBA')
   (255, 0, 0, 255)
   >>> ImageColor.getcolor('Black', 'RGBA')
   (0, 0, 0, 255)
   >>> ImageColor.getcolor('chocolate', 'RGBA')
   (210, 105, 30, 255)
   >>> ImageColor.getcolor('CornflowerBlue', 'RGBA')
   (100, 149, 237, 255)
```
colors-and-rgba-values_key18
colors-and-rgba-values_key19colors-and-rgba-values_key20