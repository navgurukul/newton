```ngMeta
working-with-the-image-data-type_key1
```
# working-with-the-image-data-type_key2
working-with-the-image-data-type_key3
working-with-the-image-data-type_key4
```python
   >>> from PIL import Image
   >>> catIm = Image.open('zophie.png')
   >>> catIm.size
```
working-with-the-image-data-type_key5```python
❷ >>> width, height = catIm.size
❸ >>> width
```
working-with-the-image-data-type_key6```python
❹ >>> height
```
working-with-the-image-data-type_key7```python
   >>> catIm.filename
```
working-with-the-image-data-type_key8```python
   >>> catIm.format
```
working-with-the-image-data-type_key9```python
   >>> catIm.format_description
```
working-with-the-image-data-type_key10```python
❺ >>> catIm.save('zophie.jpg')
```
working-with-the-image-data-type_key11
working-with-the-image-data-type_key12
working-with-the-image-data-type_key13
working-with-the-image-data-type_key14
working-with-the-image-data-type_key15
working-with-the-image-data-type_key16
working-with-the-image-data-type_key17
```python
   >>> from PIL import Image
❶ >>> im = Image.new('RGBA', (100, 200), 'purple')
   >>> im.save('purpleImage.png')
❷ >>> im2 = Image.new('RGBA', (20, 20))
   >>> im2.save('transparentImage.png')
```
working-with-the-image-data-type_key18
