```ngMeta
cropping-images_key1
```
# cropping-images_key2
cropping-images_key3
cropping-images_key4
```python
>>> croppedIm = catIm.crop((335, 345, 565, 560))
>>> croppedIm.save('cropped.png')
```
cropping-images_key5
cropping-images_key6

