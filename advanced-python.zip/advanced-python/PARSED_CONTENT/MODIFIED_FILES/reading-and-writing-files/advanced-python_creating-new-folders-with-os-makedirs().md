```ngMeta
creating-new-folders-with-os-makedirs()_key1
```
# creating-new-folders-with-os-makedirs()_key2
creating-new-folders-with-os-makedirs()_key3
```python
>>> import os
>>> os.makedirs('C:\\delicious\\walnut\\waffles')
```
creating-new-folders-with-os-makedirs()_key4
creating-new-folders-with-os-makedirs()_key5\\creating-new-folders-with-os-makedirs()_key6\\creating-new-folders-with-os-makedirs()_key7\\creating-new-folders-with-os-makedirs()_key8