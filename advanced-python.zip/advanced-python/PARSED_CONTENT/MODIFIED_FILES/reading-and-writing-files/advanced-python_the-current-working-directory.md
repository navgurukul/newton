```ngMeta
the-current-working-directory_key1
```
# the-current-working-directory_key2
the-current-working-directory_key3
```python
>>> import os
>>> os.getcwd()
'C:\\Python34'
>>> os.chdir('C:\\Windows\\System32')
>>> os.getcwd()
'C:\\Windows\\System32'
```
the-current-working-directory_key4
the-current-working-directory_key5
```python
>>> os.chdir('C:\\ThisFolderDoesNotExist')
```
the-current-working-directory_key6the-current-working-directory_key7\\the-current-working-directory_key8\\the-current-working-directory_key9
# the-current-working-directory_key10
the-current-working-directory_key11