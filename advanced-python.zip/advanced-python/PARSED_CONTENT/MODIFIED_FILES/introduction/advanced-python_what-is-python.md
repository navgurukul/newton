```ngMeta
what-is-python_key1
```
# what-is-python_key2
what-is-python_key3[what-is-python_key4](http://python.org/)
what-is-python_key5
what-is-python_key6
# what-is-python_key7
what-is-python_key8
what-is-python_key9

what-is-python_key10

# what-is-python_key11
what-is-python_key12
what-is-python_key13
# what-is-python_key14
what-is-python_key15[what-is-python_key16](http://stackoverflow.com/)
what-is-python_key17[what-is-python_key18](http://reddit.com/r/learnprogramming/)
what-is-python_key19
## what-is-python_key20
what-is-python_key21
# what-is-python_key22
what-is-python_key23
```python
  >>> '42' + 3
❶ Traceback (most recent call last):
    File "<pyshell#0>", line 1, in <module>
      '42' + 3
❷ """TypeError: Can't convert 'int' object to str "implicitly"""
  >>>
```
what-is-python_key24

what-is-python_key25
what-is-python_key26




