```ngMeta
the-wildcard-character_key1
```
# the-wildcard-character_key2
the-wildcard-character_key3
```python
>>> atRegex = re.compile(r'.at')
>>> atRegex.findall('The cat in the hat sat on the flat mat.')
['cat', 'hat', 'sat', 'lat', 'mat']
```
the-wildcard-character_key4\.the-wildcard-character_key5
# the-wildcard-character_key6
the-wildcard-character_key7```python
>>> nameRegex = re.compile(r'First Name: (.*) Last Name: (.*)')
>>> mo = nameRegex.search('First Name: Al Last Name: Sweigart')
>>> mo.group(1)
'Al'
>>> mo.group(2)
'Sweigart'
```
the-wildcard-character_key8
the-wildcard-character_key9
```python
>>> nongreedyRegex = re.compile(r'<.*?>')
>>> mo = nongreedyRegex.search('<To serve man> for dinner.>')
>>> mo.group()
'<To serve man>'

>>> greedyRegex = re.compile(r'<.*>')
>>> mo = greedyRegex.search('<To serve man> for dinner.>')
>>> mo.group()
'<To serve man> for dinner.>'
```
the-wildcard-character_key10the-wildcard-character_key11the-wildcard-character_key12the-wildcard-character_key13
