```ngMeta
combining-re-ignorecase,-re-dotall,-and-re-verbose_key1
```
# combining-re-ignorecase,-re-dotall,-and-re-verbose_key2
combining-re-ignorecase,-re-dotall,-and-re-verbose_key3
combining-re-ignorecase,-re-dotall,-and-re-verbose_key4
```python
>>> someRegexValue = re.compile('foo', re.IGNORECASE | re.DOTALL)
```
combining-re-ignorecase,-re-dotall,-and-re-verbose_key5
```python
>>> someRegexValue = re.compile('foo', re.IGNORECASE | re.DOTALL | re.VERBOSE)
```
combining-re-ignorecase,-re-dotall,-and-re-verbose_key6combining-re-ignorecase,-re-dotall,-and-re-verbose_key7combining-re-ignorecase,-re-dotall,-and-re-verbose_key8