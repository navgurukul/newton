```ngMeta
character-classes_key1
```
# character-classes_key2
character-classes_key3
character-classes_key4
character-classes_key5
character-classes_key6
character-classes_key7
character-classes_key8
character-classes_key9
character-classes_key10
character-classes_key11
character-classes_key12
character-classes_key13
character-classes_key14
```python
>>> xmasRegex = re.compile(r'\d+\s\w+')
>>> xmasRegex.findall('12 drummers, 11 pipers, 10 lords, 9 ladies, 8 maids, 7swans, 6 geese, 5 rings, 4 birds, 3 hens, 2 doves, 1 partridge')
['12 drummers', '11 pipers', '10 lords', '9 ladies', '8 maids', '7 swans', '6geese', '5 rings', '4 birds', '3 hens', '2 doves', '1 partridge']
```
character-classes_key15
